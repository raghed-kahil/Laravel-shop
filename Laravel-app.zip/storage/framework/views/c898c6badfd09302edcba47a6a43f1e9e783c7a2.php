<?php $__env->startSection('content'); ?>
  <div id="content">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <!-- breadcrumb-->
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li aria-current="page" class="breadcrumb-item active">My orders</li>
            </ol>
          </nav>
        </div>
        <div class="col-lg-3">
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.costumer-side-bar-menu','data' => ['page' => 1]]); ?>
<?php $component->withName('costumer-side-bar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['page' => 1]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div id="customer-orders" class="col-lg-9">
          <div class="box">
            <h1>My orders</h1>
            <p class="lead">Your orders on one place.</p>
            <p class="text-muted">If you have any questions, please feel free to <a href="contact">contact us</a>, our
              customer service center is working for you 24/7.</p>
            <hr>
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                <tr>
                  <th>Order</th>
                  <th>Date</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th># <?php echo e($order->id); ?></th>
                    <td><?php echo e(date('d/m/Y',strtotime($order->updated_at))); ?></td>
                    <td>$ <?php echo e($order->total); ?></td>
                    <?php switch($order->status):
                      case ('Being prepared'): ?>
                        <td><span class="badge badge-info">Being prepared</span></td>
                        <?php break; ?>
                      <?php case ('Received'): ?>
                        <td><span class="badge badge-success">Received</span></td>
                        <?php break; ?>
                      <?php case ('Cancelled'): ?>
                        <td><span class="badge badge-danger">Cancelled</span></td>
                        <?php break; ?>
                      <?php case ('On hold'): ?>
                        <td><span class="badge badge-warning">On hold</span></td>
                    <?php endswitch; ?>
                      <td><a href="/customer-orders/<?php echo e($order->id); ?>" class="btn btn-primary btn-sm">View</a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raghed\Laravel-app\resources\views/customer-orders.blade.php ENDPATH**/ ?>