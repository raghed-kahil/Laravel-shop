<?php if (! $__env->hasRenderedOnce('50e28b0a-0e07-4c00-8f4c-b977cab7ede1')): $__env->markAsRenderedOnce('50e28b0a-0e07-4c00-8f4c-b977cab7ede1'); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('.add-to-basket').click(function () {
            $.ajax({
                url: '/basket/'+$(this).attr('product'),
                type: 'PUT',
                data: {
                    'id': $(this).attr('product'),
                  '_token': '<?php echo e(csrf_token()); ?>'
        },
            success: function(response) {
                $('#basket-button').text(response+' items in cart');
            }
        });
        })
    });
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Raghed\Laravel-app\resources\views/components/add-to-basket-script.blade.php ENDPATH**/ ?>