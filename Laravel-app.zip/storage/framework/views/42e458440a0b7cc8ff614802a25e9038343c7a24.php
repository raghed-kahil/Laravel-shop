<table class="table">
  <thead>
  <tr>
    <th colspan="2">Product</th>
    <th>Quantity</th>
    <th>Unit price</th>
    <th>Discount</th>
    <th colspan="2">Total</th>
  </tr>
  </thead>
  <tbody>
  <?php
    $total = 0;
  ?>
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <?php
        $x  = ( $product->price * ( 1 - $product->sale ) ) * $basket[$product->id];
        $total+=$x;
      ?>
      <td><a href="#"><img src="/img/detailsquare.jpg" alt="<?php echo e($product->name); ?>"></a></td>
      <td><a href="/products/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a></td>
      <td>
        <input type="number" min="1" max="1000" value="<?php echo e($basket[$product->id]); ?>" class="form-control">
      </td>
      <td>$<?php echo e($product->price); ?></td>
      <td>$<?php echo e($product->price * $product->sale); ?></td>
      <td>$<?php echo e($x); ?></td>
      <td><a href="#"><i class="fa fa-trash-o"></i></a></td>
    </tr>
    <?php
      $total+=$x;
    ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
  <tr>
    <th colspan="5">Total</th>
    <th colspan="2">$<?php echo e($total); ?></th>
  </tr>
  </tfoot>
</table>
<?php /**PATH C:\Users\Raghed\Laravel-app\resources\views/components/basket-table.blade.php ENDPATH**/ ?>