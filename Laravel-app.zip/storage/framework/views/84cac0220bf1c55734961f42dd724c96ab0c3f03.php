<div class="product">
  <div class="flip-container">
    <div class="flipper">
      <div class="front"><a href="/products"><img src="<?php echo e($product->img1); ?>" alt="" class="img-fluid"></a></div>
      <div class="back"><a href="/products"><img src="<?php echo e($product->img2); ?>" alt="" class="img-fluid"></a></div>
    </div>
  </div><a href="/products" class="invisible"><img src="<?php echo e($product->img1); ?>" alt="" class="img-fluid"></a>
  <div class="text">
    <h3><a href="/products"><?php echo e($product->name); ?></a></h3>
    <p class="price">
      <?php if($product->sale>0): ?>
        <del>$<?php echo e($product->price); ?></del>
        $<?php echo e($product->price-$product->price*$product->sale); ?>

      <?php else: ?>
        $<?php echo e($product->price); ?>

      <?php endif; ?>
    </p>
  </div>
  <!-- /.text-->
  <?php if($product->sale>0): ?>
  <div class="ribbon sale">
    <div class="theribbon">SALE</div>
    <div class="ribbon-background"></div>
  </div>
  <!-- /.ribbon-->
  <?php endif; ?>
  <?php if(strtotime($product->created_at) > strtotime('-7 days')): ?>
  <div class="ribbon new">
    <div class="theribbon">NEW</div>
    <div class="ribbon-background"></div>
  </div>
  <!-- /.ribbon-->
  <?php endif; ?>
  <?php if($product->gift!=null): ?>
  <div class="ribbon gift">
    <div class="theribbon"><a style="color: white" href="/products/<?php echo e($product->gift); ?>">GIFT</a></div>
    <div class="ribbon-background"></div>
  </div>
  <!-- /.ribbon-->
  <?php endif; ?>
</div>
<!-- /.product-->
<?php /**PATH C:\Users\Raghed\Laravel-app\resources\views/components/product-mini.blade.php ENDPATH**/ ?>