<!-- JavaScript files-->
<script src="/vendor/jquery/jquery.min.js"></script>
<script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/vendor/jquery.cookie/jquery.cookie.js"> </script>
<script src="/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="/vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.js"></script>
<script src="/js/front.js"></script>
